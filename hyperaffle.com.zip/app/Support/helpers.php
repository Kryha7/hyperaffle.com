<?php

    function get_name($raffle_id)
    {
        return $raffle_id;
    }
