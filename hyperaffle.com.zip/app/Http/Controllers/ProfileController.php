<?php

namespace App\Http\Controllers;

use App\Raffle;
use App\TicketsTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function index()
    {
//        $user = Auth::user();
//        $raffles = TicketsTransaction::where('user_id', $user->id)->get();

        return view('profile');
    }

    public function tickets()
    {
        return view('tickets');
    }
}
