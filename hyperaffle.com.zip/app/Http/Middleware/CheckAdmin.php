<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class CheckAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = Auth::user();

        if (empty($user->email))
        {
            return redirect('/');
        }else{
            if ($user->email != 'kryszto@icloud.com')
            {
                return redirect('/');
            }
        }

        return $next($request);
    }
}
