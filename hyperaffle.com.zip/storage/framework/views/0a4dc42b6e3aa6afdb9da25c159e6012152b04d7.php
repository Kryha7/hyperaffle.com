<?php $__env->startSection('content'); ?>
    <h1><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></h1>
    <p>Winner is <?php echo e($user->name); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>