<?php $__env->startSection('content'); ?>
<h1><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></h1>
<ul>
    <li><?php echo e($raffle->tickets); ?>/<?php echo e($raffle->max_tickets); ?></li>
</ul>
<?php echo Form::open(
    array(
        'route' => ['admin.raffle.update', $raffle],
        'class' => 'form',
        'novalidate' => 'novalidate',
    )); ?>

<?php echo Form::label('Brand'); ?>

<?php echo Form::text('brand', $raffle->brand); ?>


<?php echo Form::label('Title'); ?>

<?php echo Form::text('title', $raffle->title); ?>


<?php echo Form::label('Max tickets'); ?>

<?php echo Form::number('max_tickets', $raffle->max_tickets); ?>


<?php echo Form::submit('Edit raffle'); ?>


<?php echo Form::close(); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>