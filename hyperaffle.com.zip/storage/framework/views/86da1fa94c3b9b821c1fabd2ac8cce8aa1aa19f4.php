<?php $__env->startSection('content'); ?>
    <h1>Winners</h1>
    <ul>
        <?php $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raffle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($raffle->winner)): ?>
                <li><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?> | User id: <?php echo e($raffle->winner); ?> |
                    <?php if($raffle->shipped == 0): ?>
                        Not shipped | <a href="<?php echo e(route('admin.winner.shipped', $raffle)); ?>">Shipped</a>
                    <?php else: ?>
                        Shipped
                    <?php endif; ?>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>