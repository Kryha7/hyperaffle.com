<?php $__env->startSection('content'); ?>
    <h1>Payment transactions</h1>
    <ul>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($transaction->id); ?> | <?php echo e($transaction->payment_id); ?> | <?php echo e($transaction->user_id); ?> | <?php echo e($transaction->tickets_amount); ?> tickets</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>