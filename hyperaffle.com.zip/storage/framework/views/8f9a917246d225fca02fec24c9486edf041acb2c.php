<?php $__env->startSection('content'); ?>
    <h1><?php echo e(Auth::user()->name); ?></h1>
    <h2><?php echo e(Auth::user()->email); ?></h2>
    <p><?php echo e(Auth::user()->tickets); ?> <b>tickets</b></p>
    <ul>
        <b>My raffles</b>
        
            
        
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>