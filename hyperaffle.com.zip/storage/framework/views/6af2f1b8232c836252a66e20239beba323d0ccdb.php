<?php $__env->startSection('content'); ?>
<br/>
<ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<br/>

<h1>Create raffle</h1>
<?php echo Form::open(
    array(
        'route' => 'admin.raffle.store',
        'class' => 'form',
        'novalidate' => 'novalidate',
        'files' => true
    )); ?>


<?php echo Form::label('Main'); ?>

<?php echo Form::checkbox('main', 1); ?>


<?php echo Form::label('Brand'); ?>

<?php echo Form::text('brand'); ?>


<?php echo Form::label('Title'); ?>

<?php echo Form::text('title'); ?>


<?php echo Form::label('Max tickets'); ?>

<?php echo Form::number('max_tickets'); ?>


<?php echo Form::label('Raffle thumb'); ?>

<?php echo Form::file('thumb', null); ?>


<?php echo Form::label('Raffle preview images'); ?>

<?php echo Form::file('images[]', ['multiple' => 'multiple']);; ?>


<?php echo Form::submit('Create raffle'); ?>


<?php echo Form::close(); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>