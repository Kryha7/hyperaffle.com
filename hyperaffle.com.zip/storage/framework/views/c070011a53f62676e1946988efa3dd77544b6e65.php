<?php $__env->startSection('content'); ?>
        <h1>Raffles</h1>
        <ul>
            <?php $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raffle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset('images/'.$raffle->id.'/'.$raffle->thumb)); ?>" width="300px">
                <li><b><?php echo e($raffle->id); ?></b> | <?php if($raffle->main != null): ?> main | <?php endif; ?> <?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?> | <?php echo e($raffle->tickets); ?>/<?php echo e($raffle->max_tickets); ?> |
                    <?php if($raffle->tickets != $raffle->max_tickets): ?>
                        <a href="<?php echo e(route('admin.raffle.edit', $raffle)); ?>">Edit</a> <a href="<?php echo e(route('admin.raffle.delete', $raffle)); ?>">Delete</a></li>
                <?php else: ?>
                    <?php if(empty($raffle->winner)): ?>
                        <a href="<?php echo e(route('admin.raffle.winner', $raffle)); ?>">Raffle winner</a></li>
                    <?php else: ?>
                        <a href="<?php echo e(route('admin.raffle.show_winner', $raffle)); ?>">Show winner</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>