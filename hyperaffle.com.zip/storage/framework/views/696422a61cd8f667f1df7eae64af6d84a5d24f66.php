<?php $__env->startSection('content'); ?>
    <div class="info">

            <?php if($message = Session::get('success')): ?>
            <div class="info-success">
                <div class="ticket-info ">
                    <p><b>Added tickets</b></p>
                </div>
                <?php Session::forget('success');?>
            </div>
            <?php endif; ?>


            <?php if($message = Session::get('error')): ?>
                    <div class="info-error">
                <div class="ticket-info">
                    <p><b>You can't add more tickes</b></p>
                </div>
                <?php Session::forget('error');?>
                    </div>
            <?php endif; ?>

    </div>

    <div class="featured">
        <?php $__currentLoopData = $raffles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raffle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($raffle->main == 1): ?>
                <div class="main-raffle">
                    <a href="#<?php echo e($raffle->id); ?>"><img src="<?php echo e(asset('images/'.$raffle->id.'/'.$raffle->thumb)); ?>" alt="<?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?>"></a>
                    <div class="wrapper">
                        <span class="title-brand"><b><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></b></span><br>
                        <span class="raffle-tickets"><b><?php echo e($raffle->tickets); ?></b> / <?php echo e($raffle->max_tickets); ?> tickets</span><br>
                        <?php if($raffle->tickets != $raffle->max_tickets): ?>
                            <span class="raffle-status" style="color:#008000;"><b>Raffle open</b></span>
                        <?php elseif($raffle->tickets == $raffle->max_tickets): ?>
                            <span class="raffle-status" style="color:#ff4500;"><b>Raffle closed</b></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="remodal" data-remodal-id="<?php echo e($raffle->id); ?>" role="dialog" aria-labelledby="modal1Title" aria-describedby="modal1Desc">
                    <button data-remodal-action="close" class="remodal-close" aria-label="Close"></button>
                    <?php if(auth()->guard()->guest()): ?>
                        <div>
                            <div>
                                <h2>Login to take in</h2>
                            </div>
                            <br>
                            <a href="<?php echo e(route('login')); ?>"><button class="remodal-login">Login with Facebook</button></a>
                        </div>
                    <?php else: ?>
                        <?php if($raffle->tickets != $raffle->max_tickets): ?>
                        <div>
                            <?php if(Auth::user()->tickets == 1): ?>
                                <h2>Currently you have <?php echo e(Auth::user()->tickets); ?> ticket</h2>
                            <?php else: ?>
                                <h2>Currently you have <?php echo e(Auth::user()->tickets); ?> tickets</h2>
                            <?php endif; ?>
                            <p><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></p>
                            <p><b><?php echo e($raffle->tickets); ?></b> / <?php echo e($raffle->max_tickets); ?> tickets</p>
                            <div class="tickets-form">
                                <?php echo Form::open(
                                    array(
                                       'route' => ['add_tickets', $raffle],
                                               'class' => 'form',
                                               'novalidate' => 'novalidate',
                                           )); ?>

                                    <input type="number" name="tickets" class="form-number">

                            </div>
                        </div>
                        <br>
                        <button type="submit" class="remodal-confirm">Take in</button>
                            <?php echo Form::close(); ?>

                        <?php elseif($raffle->tickets == $raffle->max_tickets): ?>
                            <div>
                                <h2>Raffle closed</h2>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <div class="raffles">
            <?php else: ?>
                <div class="raffle">
                    <a href="#<?php echo e($raffle->id); ?>"><img src="<?php echo e(asset('images/'.$raffle->id.'/'.$raffle->thumb)); ?>" alt="<?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?>"></a>
                    <div class="wrapper">
                        <span class="title-brand"><b><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></b></span><br>
                        <span class="raffle-tickets"><b><?php echo e($raffle->tickets); ?></b> / <?php echo e($raffle->max_tickets); ?> tickets</span><br>
                                <?php if($raffle->tickets != $raffle->max_tickets): ?>
                            <span class="raffle-status" style="color:#008000;"><b>Raffle open</b></span>
                                <?php elseif($raffle->tickets == $raffle->max_tickets): ?>
                            <span class="raffle-status" style="color:#ff4500;"><b>Raffle closed</b></span>
                                <?php endif; ?>
                    </div>
                </div>
                    <div class="remodal" data-remodal-id="<?php echo e($raffle->id); ?>" role="dialog" aria-labelledby="modal1Title" aria-describedby="modal1Desc">
                        <button data-remodal-action="close" class="remodal-close" aria-label="Close"></button>
                        <?php if(auth()->guard()->guest()): ?>
                            <div>
                                <div>
                                    <h2>Login to take in</h2>
                                </div>
                                <br>
                                <a href="<?php echo e(route('login')); ?>"><button class="remodal-login">Login with Facebook</button></a>
                            </div>
                        <?php else: ?>
                            <?php if($raffle->tickets != $raffle->max_tickets): ?>
                                <div>
                                    <?php if(Auth::user()->tickets == 1): ?>
                                        <h2>Currently you have <?php echo e(Auth::user()->tickets); ?> ticket</h2>
                                    <?php else: ?>
                                        <h2>Currently you have <?php echo e(Auth::user()->tickets); ?> tickets</h2>
                                    <?php endif; ?>
                                    <p><?php echo e($raffle->brand); ?> <?php echo e($raffle->title); ?></p>
                                    <p><b><?php echo e($raffle->tickets); ?></b> / <?php echo e($raffle->max_tickets); ?> tickets</p>
                                    <div class="tickets-form">
                                        <?php echo Form::open(
                                            array(
                                               'route' => ['add_tickets', $raffle],
                                                       'class' => 'form',
                                                       'novalidate' => 'novalidate',
                                                   )); ?>

                                        <input type="number" name="tickets" class="form-number">
                                    </div>
                                </div>
                                <br>
                                <button type="submit" class="remodal-confirm">Take in</button>
                                <?php echo Form::close(); ?>

                            <?php elseif($raffle->tickets == $raffle->max_tickets): ?>
                                <div>
                                    <h2>Raffle closed</h2>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>