<?php $__env->startSection('content'); ?>
    <h1><?php echo e($user->name); ?> | <?php echo e($user->email); ?></h1>
    <ul>
        <li><?php echo e($user->tickets); ?> tickets</li>
    </ul>
    <?php echo Form::open(
        array(
            'route' => ['admin.user.update', $user],
            'class' => 'form',
            'novalidate' => 'novalidate',
        )); ?>

    <?php echo Form::label('Name'); ?>

    <?php echo Form::text('name', $user->name); ?>


    <?php echo Form::label('Email'); ?>

    <?php echo Form::text('email', $user->email); ?>


    <?php echo Form::label('Tickets'); ?>

    <?php echo Form::number('tickets', $user->tickets); ?>


    <?php echo Form::submit('Edit user'); ?>


    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>