<?php $__env->startSection('content'); ?>
    <div class="container-about">
        <div class="left-nav">
            <ul>
                <li><a href="<?php echo e(route('about.us')); ?>">About us</a></li>
                <li class="active"><a href="<?php echo e(route('about.jobs')); ?>">Jobs</a></li>
                <li><a href="#">Support</a></li>
                <li><a href="<?php echo e(route('about.privacy')); ?>">Privacy</a></li>
                <li><a href="<?php echo e(route('about.terms')); ?>">Terms</a></li>
            </ul>
        </div>
        <div class="right-content">
            <h1>Jobs</h1>
            <img src="<?php echo e(asset('images/jobs.png')); ?>" width="653px" height="435px">
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>