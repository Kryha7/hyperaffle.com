@extends('layouts.site')
@section('content')
    <h1>{{ Auth::user()->name }}</h1>
    <h2>{{ Auth::user()->email }}</h2>
    <p>{{ Auth::user()->tickets }} <b>tickets</b></p>
    <ul>
        <b>My raffles</b>
        {{--@foreach($raffles as $raffle)--}}
            {{--<li><b>{{$raffle->amount}}</b> tickets to <b>{{get_name($raffle->raffle_id)}}</b></li>--}}
        {{--@endforeach--}}
    </ul>
@endsection