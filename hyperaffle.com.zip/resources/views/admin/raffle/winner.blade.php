@extends('layouts.admin')
@section('content')
    <h1>{{$user->name}}</h1>
    <h1>{{$user->email}}</h1>
@endsection