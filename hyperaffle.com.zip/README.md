# hyperaffle.com
### to do list
* crur (create, read, update, raffle)
* paypal payment
* login with facebook
